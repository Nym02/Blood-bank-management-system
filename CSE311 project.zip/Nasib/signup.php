<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/signup.css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
  <title>Signup</title>
</head>
<body>


  <div class="container">

    <div class="header-area">
        <div class="logo1">
        <img src="img/logo.jpg" alt="Blood donation" />
        <p>A Community of Voluntary Blood Donors of Bangladesh</p>

        </div>
        <div class="logo2">
          <img src="img/savelife.png" alt="Save Life" />

        </div>

    </div>
    <nav class="menu-bar">
	<ul>
		<li><a href="index.php">Home</a></li>
      <li><a href="ask-for-blood.php">ask for blood</a></li>
      <li><a href="Donation.php"> donate blood</a></li>
      <li><a href="avaibility.php">availibility</a></li>
      <li><a href="login.php">login</a>
			<ul>
			<li><a href="login.php">user login</a>
			<li><a href="Admin_login/login.php">admin login</a>
			<li><a href="volunteer/login.php">volunteer login</a>
			
			</ul>
	  </li>
	  <li><a href="signup.php">signup</a></li>

	</ul>
	</nav>
       <h2>	<center> Signup</center></h2>	
	   <form class="signup-form" action="includes/signup.inc.php" method="POST">
			<input type="text" name="first_name" placeholder="Firstname">
			<input type="text" name="last_name" placeholder="Lastname">
			<input type="text" name="email" placeholder="E-mail">
			<input type="text" name="phone" placeholder="Phone No">
			<input type="text" name="uid" placeholder="Username">
			<input type="password" name="pass" placeholder="Password">
			<button type="submit" name="submit" > Sign up </button>
	   
	   </form>
	
  <footer class="footer-area">
        <p>&copy; Copyright All Rights Reserved</p>

  </footer>

</body>
</html>
