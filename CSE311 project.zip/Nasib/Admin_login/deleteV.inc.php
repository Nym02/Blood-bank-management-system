<?php
include 'dbh.inc.php';
         $sql="DELETE FROM volunteer  WHERE v_id=$_POST[id]";
		 if(mysqli_query($conn,$sql))
		 {
			 header("Location:deleteV.php.?success");
		 }
		 else
		 {
			 echo "Not update";
		 }
		 
		 
?>