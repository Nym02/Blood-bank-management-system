
<?php
session_start();

if(!isset($_SESSION['u_id']))
{
	header("Location:../nasib/login.php");
    exit;
}
include_once "includes/dbh.inc.php";


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/avaibility.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>Blood Availibility</title>
</head>
<body>
  <div class="container">

  	<div class="header-area">
  			<div class="logo1">
  			<img src="img/logo.jpg" alt="Blood donation" />
  			<p>A Community of Voluntary Blood Donors of Bangladesh</p>

  			</div>
  			<div class="logo2">
  				<img src="img/savelife.png" alt="Save Life" />

  			</div>

  	</div>

  	<nav class="menu-bar">

  	<ul>
  		<li><a href="home.php">Home</a></li>
      <li><a href="ask-for-blood.php">ask for blood</a></li>
      <li><a href="Donation.php"> donate blood</a></li>
      <li><a href="avaibility.php">availibility</a></li>
     <li><a href="logout.php">Log out</a></li>
	  

  	</ul>
  	</nav>
    <div class="pre-text">
        <marquee >Here you will find all of our available blood sample</marquee>


    </div>

  <section id="blood-info-A-pos" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>A positive blood(A+) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-A+.php">
          <img src="img/a-positive.jpg" alt=" A positive blood" title="A positive blood group list" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>
  <section id="blood-info-A-neg" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>A Negative blood(A-) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-A-.php">
          <img src="img/A-Negative.jpg" alt=" A Negative blood" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>

  <section id="blood-info-B-pos" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>B Positive blood(B+) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-B+.php">
          <img src="img/b-pos.jpg" alt=" B Positive blood" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>

  <section id="blood-info-B-neg" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>B Negative blood(B-) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-B-.php">
          <img src="img/b-neg.jpg" alt=" B Negative blood" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>

  <section id="blood-info-AB-pos" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>AB Positive blood(AB+) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-AB+.php">
          <img src="img/ab-pos.jpg" alt=" AB Positive blood" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>

  <section id="blood-info-AB-neg" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>AB Negative blood(AB-) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-AB-.php">
          <img src="img/ab-neg.jpg" alt=" AB Negative blood" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>

  <section id="blood-info-O-pos" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>O Positive blood(O+) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-O+.php">
          <img src="img/o-pos.jpg" alt=" O Positive blood" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>

  <section id="blood-info-O-neg" class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>O Negative blood(O-) facts</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, neque, reprehenderit. Facilis, illum accusamus porro! Porro suscipit nihil, hic odit. <a href="">Click here or the image to see the blood group list.</a></p>
          <a href="#" class="btn btn-outline-dark">Read more</a>
        </div>
        <div class="col-md-6">
          <a href="blood-O-.php">
          <img src="img/o-negative.jpg" alt=" O Negative blood" class="img-fluid">
          </a>
        </div>
      </div>
    </div>
  </section>

<section id="copyright" class="text-center py-3 bg-dark text-light">
  <div class="container">
    <div class="row">
      <div class="col">
        <p class="lead mb-0">Copyright 2018 &copy; Nasib and Nayeem </p>
      </div>
    </div>
  </div>
</section>
</div>

  <script src="js/bootstrap.min.js">

  </script>
</body>
</html>
