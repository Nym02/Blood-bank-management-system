<?php
session_start();

if(!isset($_SESSION['u_id']))
{
	header("Location:../nasib/login.php");
    exit;
}



?>




<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/home.css" media="all" />
	<!-- <link rel="stylesheet" type="text/css" href="css/home-2.scss" media="all" /> -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/fontawesome-all.min.css">
</head>
<body>




<div class="wcontainer">

	<div class="header-area">
			<div class="logo1">
			<img src="img/logo.jpg" alt="Blood donation" />
			<p>A Community of Voluntary Blood Donors of Bangladesh</p>
			

			</div>
			<div class="logo2">
				<img src="img/savelife.png" alt="Save Life" />

			</div>

	</div>
	<nav class="menu-bar">
	<ul>
		<li><a href="home.php">home</a></li>
      <li><a href="ask-for-blood.php">ask for blood</a></li>
      <li><a href="Donation.php"> donate blood</a></li>
      <li><a href="avaibility.php">availibility</a></li>
      <li><a href="logout.php">Log out</a></li>

	</ul>
	</nav>
	<!-- <div class="main-content">
		<img src="img/bmh.jpg" alt="blood" />

	</div> -->

	<!-- -----carousel slider-------------- -->
	<section id="showcase" class="bg-dark">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-slide-to="0" data-target="#myCarousel" class="active bg-dark"></li>
        <li data-slide-to="1" data-target="#myCarousel" class="bg-dark" ></li>
        <li data-slide-to="2" data-target="#myCarousel" class="bg-dark"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item carousel-img-1 active">
          <div class="container">
            <div class="carousel-caption mb-5 pb-5">
              <!-- <h2 class="display-4 text-dark">Slogan</h2>
              <p class="lead my-4 text-dark">“The Blood You Donate Gives Someone Another Chance At Life. One Day That Someone May Be A Close Relative, A Friend, A Loved One—Or Even You.”</p> -->
              <!-- <a href="#" class="btn btn-danger">Learn More</a> -->
            </div>
          </div>
        </div>
        <div class="carousel-item carousel-img-2">
          <div class="container">
            <div class="carousel-caption mb-5 pb-5 text-right">
              <!-- <h2 class="display-4">Heading Two</h2>
              <p class="lead my-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corrupti repellat possimus doloribus velit, harum accusantium quia repellendus debitis, neque vero.</p>
              <a href="#" class="btn btn-success">Learn More</a> -->
            </div>
          </div>
        </div>
        <div class="carousel-item carousel-img-3">
          <div class="container">
            <div class="carousel-caption text-left text-light mb-5 pb-5">
              <!-- <h2 class="display-4 text-dark">Slogan-1</h2>
              <p class="lead my-4 text-dark">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corrupti repellat possimus doloribus velit, harum accusantium quia repellendus debitis, neque vero.</p>
              <a href="#" class="btn btn-outline-light">Learn More</a> -->
            </div>
          </div>
        </div>
      </div>
      <a href="#myCarousel" class="carousel-control-prev pb-5" data-slide="prev">
        <span class="carousel-control-prev-icon bg-dark"></span>
      </a>
      <a href="#myCarousel" class="carousel-control-next text-dark pb-5" data-slide="next">
        <span class="carousel-control-next-icon bg-dark"></span>
      </a>
    </div>
  </section>
	<section class="text-center my-4 bg-muted">
		<h1 class="display-4">Why you should donate blood?</h1>
	</section>

	<!-- <-------------Reasons------------------- -->


	<section id="reason">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<!-- <i class="fas fa-question"></i> -->
					<h2 class="display-4">Reason One</h2>
					<p class="lead">Every two seconds, someone in the United States needs blood.  That means more than 38,000 blood donations are needed per day.  Currently, less than 38% of the population is eligible to give blood, with only 3 out of every 100 Americans actually donating.  It’s a very elite group, but they’re always looking to expand membership.</p>
				</div>
				<div class="col-md-4">
					<h2 class="display-4">Reason Two</h2>
					<p class="lead">Donating blood is a simple four-step process:  registration, medical history and mini-physical, donation and refreshments (cookies!)  The whole process takes no more than one hour and 15 minutes with the actual blood collection taking about 12 minutes.</p>
				</div>
				<div class="col-md-4">
					<h2 class="display-4">Reason Three</h2>
					<p class="lead">Donating blood is a simple four-step process:  registration, medical history and mini-physical, donation and refreshments (cookies!)  The whole process takes no more than one hour and 15 minutes with the actual blood collection taking about 12 minutes.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<h2 class="display-4">Reason Four</h2>
					<p class="lead">The two most common reasons people don’t give blood are, “I never thought about it” and “I don’t like needles.”   Well, we’re thinking about it right now!  And, let’s face it, as cancer survivors, haven’t we dealt with much worse than a needle prick.  Plus, blood donation is an opportunity to volunteer, rather than be drafted.  Wouldn’t it feel good to put out your arm for a cause and walk away knowing you’ve contributed to the good health of someone other than yourself?</p>

				</div>
				<div class="col-md-4">
					<h2 class="display-4">Reason Five</h2>
					<p class="lead">More than 1 million new people are diagnosed with cancer each year.  Many of them will need blood, sometimes daily, during their chemotherapy treatment.</p>

				</div>
				<div class="col-md-4">
					<h2 class="display-4">Reason Six</h2>
					<p class="lead">Cancer is the most feared and deadly disease. Blood donation helps in lowering the risk of cancer. By donating blood regularly the iron level in the blood is balanced and the risk of cancer-related to the liver, lungs, and intestine gets lower.</p>
				</div>

			</div>
		</div>

	</section>

	<section id="home-video" class="text-center text-light">
		<div class="dark-overlay">
			<div class="container">
				<div class="row">
					<div class="col mt-5 pt-4">
						<div>
							<a  class=" text-light" href="https://youtu.be/XsbkWFfHCDk" target="_blank">
								<i class="fab fa-youtube"></i>
							</a>
						</div>
						<h2>Know the pre-requisite before donating blood.</h2>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="gallery" class="py-5" uk-lightbox>
		<div class="container">
			<div class="row text-center">
				<div class="col">
					<h2 class="display-4">Donor's Photo</h2>
					<p class="lead">Check out our photos</p>
				</div>

			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="">
						<a href="img/donation1.jpg">
							<img src="img/donation1.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div class="">
						<a href="img/donation2.jpg">
							<img src="img/donation2.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div class="">
						<a href="img/donation3.jpg">
							<img src="img/donation3.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
			</div>
			<div class="row mt-5">
				<div class="col-md-4">
					<div class="">
						<a href="img/donation4.jpg">
							<img src="img/donation4.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div class="">
						<a href="img/donation5.jpg">
							<img src="img/donation5.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div class="">
						<a href="img/donation9.jpg">
							<img src="img/donation9.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
			</div>

		</div>

	</section>

	<!-- <div class="reasons">

			<h1>Why you should donate blood?</h1>
			<div class="hr"><hr></div>
			<h3>Reason 1:</h3>
			<p id="reason1">Every two seconds, someone in the United States needs blood.  That means more than 38,000 blood donations are needed per day.  Currently, less than 38% of the population is eligible to give blood, with only 3 out of every 100 Americans actually donating.  It’s a very elite group, but they’re always looking to expand membership.</p>
			 <div class="p-img">
				<img src="img/give.jpg" alt="">
			</div>


			<h3>Reason 2:</h3>
			<p id="reason2">There are four types of transfusable products that can be derived from a pint of whole blood: red cells, platelets, plasma and cryoprecipitate.  As each pint of donated whole blood is separated into two or three of these products, each donation can help save up to three lives</p>


			<h3>Reason 3:</h3>
			<p id="reason3">Donating blood is a simple four-step process:  registration, medical history and mini-physical, donation and refreshments (cookies!)  The whole process takes no more than one hour and 15 minutes with the actual blood collection taking about 12 minutes.</p>


			<h3>Reason 4:</h3>
			<p id="reason4">The two most common reasons people don’t give blood are, “I never thought about it” and “I don’t like needles.”   Well, we’re thinking about it right now!  And, let’s face it, as cancer survivors, haven’t we dealt with much worse than a needle prick.  Plus, blood donation is an opportunity to volunteer, rather than be drafted.  Wouldn’t it feel good to put out your arm for a cause and walk away knowing you’ve contributed to the good health of someone other than yourself?</p>


			<h3>Reason 5:</h3>
			<p id="reason5">More than 1 million new people are diagnosed with cancer each year.  Many of them will need blood, sometimes daily, during their chemotherapy treatment.</p>

	</div> -->
	<section id="copyright" class="text-center py-3 bg-dark text-light">
	  <div class="container">
	    <div class="row">
	      <div class="col">
	        <p class="lead mb-0">Copyright 2018 &copy; Nasib and Nayeem </p>
	      </div>
	    </div>
	  </div>
	</section>


</div>









<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>
