<?php
include 'dbh.inc.php';
         $sql="DELETE FROM store  WHERE b_id=$_POST[id]";
		 if(mysqli_query($conn,$sql))
		 {
			 header("Location:update_store.php?success");
		 }
		 else
		 {
			 echo "Not update";
		 }
		 
		 
?>