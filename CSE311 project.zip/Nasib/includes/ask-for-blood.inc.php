<?php

if(isset($_POST['submit'])){

	include_once 'dbh.inc.php';
	$uid=mysqli_real_escape_string($conn,$_POST['uid']);
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$phone=mysqli_real_escape_string($conn,$_POST['phone']);
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$adds=mysqli_real_escape_string($conn,$_POST['address']);
	$bgroup=mysqli_real_escape_string($conn,$_POST['bgroup']);
	
	$sql="SELECT * FROM users WHERE user_uid='$uid'";
		$result=mysqli_query($conn,$sql);
		$resultCheck=mysqli_num_rows($result);
		if ($resultCheck <1) {

			header("Location:../ask-for-blood.php?login=Wrong_user_name");
			exit();
		}
		else{



	//error handler
	//check for empty fields
	if (empty($uid)||empty($name) || empty($phone) ||empty($email)|| empty($adds) || empty($bgroup) ) {

		header("Location: ../ask-for-blood.php?signup=empty");
	    exit();
	}else{

		if (!preg_match("/^[a-zA-Z]*$/", $name) ) {

			header("Location: ../ask-for-blood.php?signup=invalid");
	        exit();
		}else{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				header("Location: ../ask-for-blood.php?signup=invalid_email");
	             exit();			
		}
		else{

			if (!is_numeric($phone)) {
				header("Location: ../ask-for-blood.php?signup=invalid_phone");
	             exit();
				
			}
		   else{

				$sql="INSERT INTO request(user_uid,R_name ,R_phone ,R_email,R_address,R_BGroup  ) 
				VALUES ('$uid','$name','$phone','$email','$adds','$bgroup');";
				mysqli_query($conn,$sql);
				$sql1="SELECT * FROM store WHERE b_group='$bgroup'";
				$result0=mysqli_query($conn,$sql1);
		         $resultCheck0=mysqli_num_rows($result0);
				 if($resultCheck0 <1)
				 {
					header("Location: ../sorry.php?signup=Sorry");
	             exit(); 
				 }
				 else
				 {
					 header("Location: ../collect.php?signup=1");
	                 exit();
				 }
				 
				
	         }



			}
		}

	}


 }
 
} else {
	header("Location: ../ask-for-blood.php");
	exit();
}
