
<?php
session_start();

if(!isset($_SESSION['u_id']))
{
	header("Location:../nasib/login.php");
    exit;
}
include_once "includes/dbh.inc.php";


?>












<?php
include_once "includes/dbh.inc.php";
$query = "SELECT * FROM donor where D_BGroup='O+'";
$result = mysqli_query($conn,$query);

?>





<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/blood-O+.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>Document</title>
</head>
<body>
  <div class="container">

  	<div class="header-area">
  			<div class="logo1">
  			<img src="img/logo.jpg" alt="Blood donation" />
  			<p>A Community of Voluntary Blood Donors of Bangladesh</p>

  			</div>
  			<div class="logo2">
  				<img src="img/savelife.png" alt="Save Life" />

  			</div>

  	</div>

  	<nav class="menu-bar">

  	<ul>
  		<li><a href="home.php">Home</a></li>
      <li><a href="ask-for-blood.php">ask for blood</a></li>
      <li><a href="Donation.php"> donate blood</a></li>
      <li><a href="avaibility.php">availibility</a></li>
     <li><a href="logout.php">Log out</a></li>

  	</ul>
  	</nav>

    <div class="blood-list">

      <h1 class="display-4">Blood Group List:</h1>
      <p class=" text-primary">Here you will find the list of all A positive(O+) blood group holders.We will help you to get your desire blood group whenever you need blood.This list will contain informationa about the donor's .If you are still unable to contact with the just let us know.</p>
      <div class="table-info">
        <table class="table table-bordered table-hover">
          <thead class="table-light ">
             <tr>
              
              <th>Donor's Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Address</th>
              <th>Blood Group</th>
              <th>Last Day of Donation</th>
              
            </tr>
          </thead>
          <tbody>


          <?php
          while($sql = mysqli_fetch_assoc($result)) {?>
          <tr>
           
            <td><?php echo $sql['D_name'] ?></td>
            <td><?php echo $sql['D_phone'] ?></td>
            <td><?php echo $sql['D_email'] ?></td>
            <td><?php echo $sql['D_address'] ?></td>
            <td><?php echo $sql['D_BGroup'] ?></td>
            <td><?php echo $sql['last_donation'] ?></td>
            

          </tr>
          <?php

           };?>

  </tbody>

        </table>
      </div>

    </div>
  </div>
</body>
</html>
