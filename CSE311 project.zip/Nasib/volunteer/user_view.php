
<?php
session_start();

if(!isset($_SESSION['v_id']))
{
	header("Location:login.php");
    exit;
}
include_once "dbh.inc.php";


?>









<?php
include_once "dbh.inc.php";
$query = "SELECT * FROM users";
$result = mysqli_query($conn,$query);
$re=$result;

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin Home</title>
  <link rel="stylesheet" href="css/volunteer-home.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
  <div class="Wcontainer">

  	<div class="header-area">
  			<div class="logo1">
  			<img src="img/logo.jpg" alt="Blood donation" />
  			<p>A Community of Voluntary Blood Donors of Bangladesh</p>

  			</div>
  			<div class="logo2">
  				<img src="img/savelife.png" alt="Save Life" />

  			</div>

  	</div>
    <nav class="navbar navbar-dark bg-dark  navbar-expand-md">

        <div class="container">
          <a class="navbar-brand active" href="volunteer.php">Home</a>
          <ul class="navbar-nav">

             <li class="nav-item"><a class="nav-link" href="user_view.php">add User</a></li>
              <li class="nav-item"><a class="nav-link" href="user_view.php">view user</a></li>
              <li class="nav-item"><a class="nav-link" href="delete_user.php">delete user</a></li>
              <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
              
          </ul>
      </div>
    </nav>
    </nav>



<div class="blood-list">

      <h1 class="display-4">User List:</h1>
      
      <div class="table-info">
        <table class="table table-bordered table-hover">
          <thead class="table-light ">
            <tr>
              <th>ID</th>
              <th>First_Name</th>
			  <th>Last_Name</th>
			  <th>Email</th>
              <th>Phone</th>
              
              <th>user_name</th>
              <th>password</th>
            </tr>
          </thead>
          <tbody>


          <?php
          while($sql = mysqli_fetch_assoc($result)) {?>
          <tr>
            <td><?php echo $sql['user_id'] ?></td>
            <td><?php echo $sql['first_name'] ?></td>
            <td><?php echo $sql['last_name'] ?></td>
			      <td><?php echo $sql['user_email'] ?></td>
			      <td><?php echo $sql['user_phone'] ?></td>
            <td><?php echo $sql['user_uid'] ?></td>
            <td><?php echo $sql['user_pass'] ?></td>

          </tr>
          <?php

           };?>

  </tbody>

        </table>
      </div>

    </div>


</div>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
































