<?php

session_start();


?>

<?php
session_start();

if(!isset($_SESSION['a_id']))
{
	header("Location:login.php");
    exit;
}
include_once "dbh.inc.php";


?>


<!DOCtype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/signup.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
  <title>Signup</title>
</head>
<body>
  <div class="container">

    <div class="header-area">
        <div class="logo1">
        <img src="img/logo.jpg" alt="Blood donation" />
        <p>A Community of Voluntary Blood Donors of Bangladesh</p>

        </div>
        <div class="logo2">
          <img src="img/savelife.png" alt="Save Life" />

        </div>

    </div>
    <nav class="navbar navbar-dark bg-dark  navbar-expand-md">

        <div class="container">
          <a class="navbar-brand active" href="admin-home.php">Home</a>
          <ul class="navbar-nav">

              <li class="nav-item"><a class="nav-link" href="user_view.php">View User</a></li>
              <li class="nav-item"><a class="nav-link" href="delete_user.php">Delete user</a></li>
              <li class="nav-item"><a class="nav-link" href="signup.php">Add Volunteer</a></li>
			  <li class="nav-item"><a class="nav-link" href="update.php">update Volunteer</a></li>
              <li class="nav-item"><a class="nav-link" href="volunteer_view.php">View Volunteer</a></li>

              <li class="nav-item"><a class="nav-link" href="deleteV.php">Delete Volunteer</a></li>
              <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
          </ul>
      </div>
    </nav>


    	<?php
         include 'dbh.inc.php';
         $sql="SELECT * FROM users ";
		 $result=mysqli_query($conn,$sql);

         ?>
         <table>
         	<tr>
         		<th>first_name</th>
         		<th>last_name</th>
         		<th>user_email</th>
         		<th>user_phone</th>
         		<th>user_uid</th>
         		<th>user_pass</th>
   
         	</tr>

         	<?php
         	while ($row=mysqli_fetch_array($result)) {

         		echo "<tr><form action='delete.inc.php' method=POST>";
         		echo "<td><input type=text name=fname value='".$row['first_name']."'</td>";
         		echo "<td><input type=text name=lname value='".$row['last_name']."'</td>";
         		echo "<td><input type=text name=email value='".$row['user_email']."'</td>";
         		echo "<td><input type=text name=phone value='".$row['user_phone']."'</td>";
         		echo "<td><input type=text name=uid value='".$row['user_uid']."'</td>";
         		echo "<td><input type=text name=pass value='".$row['user_pass']."'</td>";
				echo "<td><input type=hidden name=id value='".$row['user_id']."'</td>";
				
				echo "<td><input type=submit value=Delete>";
				echo"</form></tr>";
         	}


         	?>



         </table>








       
	
  <footer class="footer-area">
        <p>&copy; Copyright All Rights Reserved</p>

  </footer>

</body>
</html>