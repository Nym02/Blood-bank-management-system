
<?php
session_start();

if(!isset($_SESSION['v_id']))
{
	header("Location:login.php");
    exit;
}
include_once "dbh.inc.php";


?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Volunteer | Home</title>
  <link rel="stylesheet" href="css/volunteer.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
  <div class="Wcontainer">

  	<div class="header-area">
  			<div class="logo1">
  			<img src="img/logo.jpg" alt="Blood donation" />
  			<p>A Community of Voluntary Blood Donors of Bangladesh</p>

  			</div>
  			<div class="logo2">
  				<img src="img/savelife.png" alt="Save Life" />

  			</div>

  	</div>
    <nav class="navbar navbar-dark bg-dark  navbar-expand-md">

        <div class="container">
          <a class="navbar-brand active" href="volunteer.php">Home</a>
          <ul class="navbar-nav">

              <li class="nav-item"><a class="nav-link" href="update_store.php">modify store</a></li>
              <li class="nav-item"><a class="nav-link" href="user_view.php">View User</a></li>
              <li class="nav-item"><a class="nav-link" href="delete_user.php">Delete User</a></li>
              <!-- <li class="nav-item"><a class="nav-link" href="">Add Volunteer</a></li>
              <li class="nav-item"><a class="nav-link" href="">Edit Volunteer</a></li>

              <li class="nav-item"><a class="nav-link" href="">Delete Volunteer</a></li> -->
              <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
          </ul>
      </div>
    </nav>
    <div class="dashboard">
      <div class="user">
          <div class="add-user">
            <a href="update_store.php"><img src="img/add-user.png" alt="modify store">
              <h2>modify store</h2>
            </a>
          </div>
          <div class="edit-user">
            <a href="user_view.php"><img src="img/edit-user.png" alt="View User">
            <h2>View User</h2></a>
          </div>
          <div class="del-user">
            <a href="delete_user.php"><img src="img/man.png" alt="Delete User">
            <h2>Delete User</h2></a>
          </div>
      </div>

      <!-- <div class="volunteer">

          <div class="add-vol">
            <a href="#">
              <img src="img/add-vol.png" alt="Add Volunteer">
              <h2>Add Volunteer</h2>
            </a>
          </div>
          <div class="edit-vol">
            <a href="#">
              <img src="img/edit-vol.png" alt="Update Volunteer">
              <h2>Update Volunteer</h2>
            </a>
          </div>
          <div class="del-vol">
            <a href="#">
              <img src="img/del-vol.png" alt="Delete Volunteer">
              <h2>Delete Volunteer</h2>
            </a>
          </div>

      </div> -->
    </div>
<section id="copyright" class="text-center py-3 bg-dark text-light">
  <div class="container">
    <div class="row">
      <div class="col">
        <p class="lead mb-0">Copyright 2018 &copy; Nasib and Nayeem </p>
      </div>
    </div>
  </div>
</section>
</div>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
