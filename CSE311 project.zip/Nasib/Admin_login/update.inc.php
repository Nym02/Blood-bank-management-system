<?php
include 'dbh.inc.php';
         $sql="UPDATE volunteer SET first_name='$_POST[fname]',last_name='$_POST[lname]',v_email='$_POST[email]',v_phone='$_POST[phone]',v_uid='$_POST[uid]',v_pass='$_POST[pass]' WHERE v_id=$_POST[id]";
		 if(mysqli_query($conn,$sql))
		 {
			 header("Location:update.php?success");
		 }
		 else
		 {
			 echo "Not update";
		 }
		 
		 
?>