<?php
session_start();

if(!isset($_SESSION['u_id']))
{
	header("Location:../nasib/login.php");
    exit;
}



?>




<!DOCname html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/signup.css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
  <title>Donation</title>
</head>
<body>


  <div class="container">

    <div class="header-area">
        <div class="logo1">
        <img src="img/logo.jpg" alt="Blood donation" />
        <p>A Community of Voluntary Blood Donors of Bangladesh</p>

        </div>
        <div class="logo2">
          <img src="img/savelife.png" alt="Save Life" />

        </div>

    </div>
    <nav class="menu-bar">
    <ul>
      <li><a href="home.php">Home</a></li>
      <li><a href="ask-for-blood.php">ask for blood</a></li>
      <li><a href="Donation.php"> donate blood</a></li>
      <li><a href="avaibility.php">availibility</a></li>
     <li><a href="logout.php">Log out</a></li>

    </ul>
    </nav>
    <form class="signup-form" action="includes/donation.inc.php" method="post">
      <h1>Donate blood </h1>
	    <input type="text" name="uid" placeholder="User_name">
        <input type="text" name="name" placeholder="Donor's Name">
        <input type="text" name="phone" placeholder="Phone">
        <input type="text" name="email" placeholder="Email">
        <input type="text" name="address" placeholder="Address">
       
		<select name="b_group" >
		<option value="A+">A+</option>
		<option value="A-">A-</option>
		<option value="B+">B+</option>
		<option value="B-">B-</option>
		<option value="AB+">AB+</option>
		<option value="AB-">AB-</option>
		<option value="O+">O+</option>
		<option value="O-">O-</option>
			
		
		</select>
        <input type="text" name="b_date" placeholder="Date of Birth">
        <input type="text" name="height" placeholder="Height">
        <input type="text" name="weight" placeholder="Weight">
        <input type="text" name="last_donation_date" placeholder="Last Donation Date">
		<button type="submit" name="submit" > submit </button>

    </form>


  </div>
  <footer class="footer-area">
        <p>&copy; Copyright All Rights Reserved</p>

  </footer>

</body>
</html>
