<?php
session_start();

if(!isset($_SESSION['u_id']))
{
	header("Location:../nasib/login.php");
    exit;
}
include_once "includes/dbh.inc.php";


?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/ask-for-blood.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Bitter" rel="stylesheet">
  <title>Ask For Blood</title>
</head>
<body>

  <div class="container">

  	<div class="header-area">
  			<div class="logo1">
  			<img src="img/logo.jpg" alt="Blood donation" />
  			<p>A Community of Voluntary Blood Donors of Bangladesh</p>

  			</div>
  			<div class="logo2">
  				<img src="img/savelife.png" alt="Save Life" />

  			</div>

  	</div>
  	<nav class="menu-bar">
  	<ul>
  		<li><a href="home.php">Home</a></li>
      <li><a href="ask-for-blood.php">ask for blood</a></li>
      <li><a href="Donation.php"> donate blood</a></li>
      <li><a href="avaibility.php">availibility</a></li>
      <li><a href="logout.php">Log out</a></li>

  	</ul>
  	</nav>
  <div class="form-area">
    <div class="form-container">
    <form class="main-form" action="includes/ask-for-blood.inc.php" method="post">
      <h1>Request for blood  </h1>
      <div class="input-area">
	  <input type="text" name="uid" placeholder="User_Name">
        <input type="text" name="name" placeholder="Your Name">

        <input type="text" name="phone" placeholder="Phone">
        <input type="text" name="email" placeholder="Email">
        <input type="text" name="address" placeholder="Address">

        <input type="text" name="bgroup" placeholder="Blood Group">
        <!-- <input type="text" placeholder="Date of Birth">
        <input type="text" placeholder="Height">
        <input type="text" placeholder="Weight">
        <input type="text" placeholder="Last Donation Date"> -->

      </div>
      <div class="submit-area">
        <input type="submit" name="submit" value="Submit">
      </div>
    </form>
</div>

  </div>


<section id="copyright" class="text-center py-3 bg-dark text-light">
  <div class="container">
    <div class="row">
      <div class="col">
        <p class="lead mb-0">Copyright 2018 &copy; Nasib and Nayeem </p>
      </div>
    </div>
  </div>
</section>
</div>
</body>
</html>
