

<?php
session_start();

if(!isset($_SESSION['v_id']))
{
	header("Location:login.php");
    exit;
}
include_once "dbh.inc.php";


?>


<!DOCtype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/signup.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
  <title>Signup</title>
</head>
<body>
  <div class="container">

    <div class="header-area">
        <div class="logo1">
        <img src="img/logo.jpg" alt="Blood donation" />
        <p>A Community of Voluntary Blood Donors of Bangladesh</p>

        </div>
        <div class="logo2">
          <img src="img/savelife.png" alt="Save Life" />

        </div>

    </div>
    <nav class="navbar navbar-dark bg-dark  navbar-expand-md">

        <div class="container">
          <a class="navbar-brand active" href="volunteer.php">Home</a>
          <ul class="navbar-nav">

              <li class="nav-item"><a class="nav-link" href="update_store.php">modify store</a></li>
              <li class="nav-item"><a class="nav-link" href="user_view.php">view user</a></li>
              <li class="nav-item"><a class="nav-link" href="delete_user.php">delete user</a></li>
              <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
          </ul>
      </div>
    </nav>


    	<?php
         include 'dbh.inc.php';
         $sql="SELECT * FROM store ";
		 $result=mysqli_query($conn,$sql);

         ?>
         <table>
         	<tr>
         		
         		<th>donor_uid</th>
         		<th>blood_group</th>
   
         	</tr>

         	<?php
         	while ($row=mysqli_fetch_array($result)) {

         		echo "<tr><form action='update_store.inc.php' method=POST>";
         		echo "<td><input type=text name=uid value='".$row['donor_uid']."'</td>";
         		echo "<td><input type=text name=pass value='".$row['b_group']."'</td>";
				echo "<td><input type=hidden name=id value='".$row['b_id']."'</td>";
				
				echo "<td><input type=submit value=Delete>";
				echo"</form></tr>";
         	}


         	?>



         </table>








       
	
  <footer class="footer-area">
        <p>&copy; Copyright All Rights Reserved</p>

  </footer>

</body>
</html>