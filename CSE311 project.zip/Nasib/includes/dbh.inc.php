<?php

$dbServername="localhost";
$dbUsername="root";
$dbPassword="12345";
$dbName="nasib";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

