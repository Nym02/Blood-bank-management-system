<?php
session_start();

if(!isset($_SESSION['u_id']))
{
	header("Location:../nasib/login.php");
    exit;
}
include_once "includes/dbh.inc.php";


?>





<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/signup.css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
  <title>Signup</title>
</head>
<body>


  <div class="container">

    <div class="header-area">
        <div class="logo1">
        <img src="img/logo.jpg" alt="Blood donation" />
        <p>A Community of Voluntary Blood Donors of Bangladesh</p>

        </div>
        <div class="logo2">
          <img src="img/savelife.png" alt="Save Life" />

        </div>

    </div>
    <nav class="menu-bar">
	<ul>
		<li><a href="index.php">Home</a></li>
      <li><a href="ask-for-blood.php">ask for blood</a></li>
      <li><a href="Donation.php"> donate blood</a></li>
      <li><a href="avaibility.php">availibility</a></li>
      <li><a href="login.php">login</a>
			<ul>
			<li><a href="login.php">user login</a>
			<li><a href="Admin_login/login.php">admin login</a>
			<li><a href="volunteer/login.php">volunteer login</a>
			
			</ul>
	  </li>
	  <li><a href="signup.php">signup</a></li>

	</ul>
	</nav>
	
	<br />
	   <br />
	   <br /> 
	   <br /> 
	   <br /> 
	
       <h4><?php echo $_SESSION['f_name']?> 	&nbsp;<?php echo $_SESSION['l_name']?> 	&nbsp; ,	&nbsp; Sorry we don't have this blood right now.we will inform you if we can manage within a short time. </h4>
	   <br />
	   <br />
	   <br /> 
	   <br /> 
	   <br /> 
	   <br />
	   <br />
	   <br /> 
	   <br /> 
	   <br /> 
	   <br />
	   <br />
	   <br /> 
	   <br /> 
	   <br /> 
	   
	   
	   
	
  <footer class="footer-area">
        <p>&copy; Copyright All Rights Reserved</p>

  </footer>

</body>
</html>