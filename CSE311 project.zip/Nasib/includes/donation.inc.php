<?php

if(isset($_POST['submit'])){

	include_once 'dbh.inc.php';

	$uid=mysqli_real_escape_string($conn,$_POST['uid']);
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$phone=mysqli_real_escape_string($conn,$_POST['phone']);
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$adds=mysqli_real_escape_string($conn,$_POST['address']);
	$bgroup=mysqli_real_escape_string($conn,$_POST['b_group']);
	$date=mysqli_real_escape_string($conn,$_POST['b_date']);
	$height=mysqli_real_escape_string($conn,$_POST['height']);
	$weight=mysqli_real_escape_string($conn,$_POST['weight']);
	$date2=mysqli_real_escape_string($conn,$_POST['last_donation_date']);
	
	
	
	$sql="SELECT * FROM users WHERE user_uid='$uid'";
		$result=mysqli_query($conn,$sql);
		$resultCheck=mysqli_num_rows($result);
		if ($resultCheck <1) {

			header("Location:../donation.php?login=Wrong_user_name");
			exit();
		}
		else{
			
	//error handler
	//check for empty fields
	if (empty($uid)|| empty($name) || empty($phone) ||empty($email)|| empty($adds) || empty($bgroup)|| empty($date) || empty($height) ||empty($weight)|| empty($date2)) {

		header("Location: ../donation.php?signup=empty");
	    exit();
	}else{

		if (!preg_match("/^[a-zA-Z]*$/", $name) ) {

			header("Location: ../donation.php?signup=invalid");
	        exit();
		}else{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				header("Location: ../donation.php?signup=invalid_email");
	             exit();			
		}
		else{

			if (!is_numeric($phone)) {
				header("Location: ../donation.php?signup=invalid_phone");
	             exit();
				
			}
		   else{

				$sql="INSERT INTO donor(user_uid,D_name ,D_phone ,D_email,D_address,D_BGroup ,D_birth_date ,D_height,D_weight ,last_donation ) 
				VALUES ('$uid','$name','$phone','$email','$adds','$bgroup','$date','$height','$weight','$date2');";
				mysqli_query($conn,$sql);
				
				$sql1="INSERT INTO store(donor_uid,b_group) VALUES('$uid','$bgroup');";
				mysqli_query($conn,$sql1);
				
				header("Location: ../donation.php?signup=success");
	             exit();
	         }



			}
		}

	}


 }
} else {
	header("Location: ../signup.php");
	exit();
}
