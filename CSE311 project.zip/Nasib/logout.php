<?php

session_start();
unset($_SESSION);
session_destroy();
header("Location:../nasib/login.php");
		exit();
?>
